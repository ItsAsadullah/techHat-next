'use client';

import { Printer } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function PrintButton({ label }: { label: string }) {
  return (
    <Button type="button" onClick={() => window.print()} className="gap-2">
      <Printer className="h-4 w-4" />
      {label}
    </Button>
  );
}
