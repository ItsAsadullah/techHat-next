'use client';

import { useEffect, useRef, useState, useCallback } from 'react';
import { usePOSCart } from '@/lib/hooks/use-pos-cart';
import { POSProductGrid } from '@/components/admin/pos/pos-product-grid';
import { POSCartPanel } from '@/components/admin/pos/pos-cart-panel';
import { ClearCartDialog } from '@/components/admin/pos/clear-cart-dialog';
import { DailyOrdersModal } from '@/components/admin/pos/daily-orders-modal';
import { completeSale, getDailySalesSummary, getPOSSalesDates, type POSProduct, type CompleteSaleInput } from '@/lib/actions/pos-actions';
import { getPOSCustomerList } from '@/lib/actions/ledger-actions';
import type { POSCustomerOption } from '@/components/admin/pos/customer-search-combobox';
import type { InvoiceSettings } from '@/lib/actions/invoice-settings-actions';
import { toast } from 'sonner';
import { Maximize, Minimize, Keyboard, BarChart2, Users, CreditCard, Grid3X3, ShoppingCart, MoreVertical, DollarSign, Package, Calendar as CalendarIcon } from 'lucide-react';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Calendar } from '@/components/ui/calendar';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { useRouter } from 'next/navigation';
import dynamic from 'next/dynamic';

// PERF: Lazy-load modal components — these are heavy (~40KB combined) and only
// rendered when explicitly triggered by user action. Loading them eagerly wastes
// bandwidth and slows initial POS page paint.
const POSReceipt = dynamic(() => import('@/components/admin/pos/pos-receipt').then(m => ({ default: m.POSReceipt })), { ssr: false });
const MixedPaymentModal = dynamic(() => import('@/components/admin/pos/mixed-payment-modal').then(m => ({ default: m.MixedPaymentModal })), { ssr: false });
const PaymentDetailsModal = dynamic(() => import('@/components/admin/pos/payment-details-modal').then(m => ({ default: m.PaymentDetailsModal })), { ssr: false });
const VariantPickerModal = dynamic(() => import('@/components/admin/pos/variant-picker-modal').then(m => ({ default: m.VariantPickerModal })), { ssr: false });

interface POSClientProps {
  categories: { id: string; name: string; productCount?: number }[];
  initialDailySummary: {
    totalSales: number;
    totalOrders: number;
    totalItems: number;
  };
  invoiceSettings: InvoiceSettings;
  initialProducts: POSProduct[];
}

export function POSClient({ categories, initialDailySummary, invoiceSettings, initialProducts }: POSClientProps) {
  const router = useRouter();
  const searchInputRef = useRef<HTMLInputElement>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [isFullscreen, setIsFullscreen] = useState(false);
  const [showShortcuts, setShowShortcuts] = useState(false);
  const [showMobileMenu, setShowMobileMenu] = useState(false);
  const [dailySummary, setDailySummary] = useState(initialDailySummary);
  const [posCustomers, setPosCustomers] = useState<POSCustomerOption[]>([]);
  const [selectedDate, setSelectedDate] = useState(() => new Date().toISOString());
  const [showOrdersModal, setShowOrdersModal] = useState(false);
  const [calendarOpen, setCalendarOpen] = useState(false);
  const [salesDates, setSalesDates] = useState<string[]>([]);

  useEffect(() => {
    // Fetch unique dates with POS sales on mount
    getPOSSalesDates().then((dates) => {
      setSalesDates(dates);
    }).catch(console.error);
  }, []);

  const handleDateChange = async (date: Date | undefined) => {
    if (!date) return;
    const newDate = date.toISOString();
    setSelectedDate(newDate);
    setCalendarOpen(false);
    
    try {
      const summary = await getDailySalesSummary(newDate);
      setDailySummary(summary);
    } catch (err) {
      console.error('Failed to fetch summary:', err);
    }
  };

  const toggleFullscreen = useCallback(async () => {
    try {
      if (!document.fullscreenElement) {
        await document.documentElement.requestFullscreen();
      } else {
        await document.exitFullscreen();
      }
      // `isFullscreen` is synced via the `fullscreenchange` listener below.
    } catch {
      // Ignore (e.g., request not initiated by a user gesture)
      setIsFullscreen(Boolean(document.fullscreenElement));
    }
  }, []);

  // Keep fullscreen UI state in sync even if user exits with Esc
  useEffect(() => {
    const sync = () => setIsFullscreen(Boolean(document.fullscreenElement));
    sync();
    document.addEventListener('fullscreenchange', sync);
    return () => document.removeEventListener('fullscreenchange', sync);
  }, []);

  // Fetch POS customers for the combobox
  useEffect(() => {
    getPOSCustomerList().then((data) => setPosCustomers(data)).catch(() => {});
  }, []);

  const [receiptData, setReceiptData] = useState<any>(null);
  const [showReceipt, setShowReceipt] = useState(false);
  const [showMixedPayment, setShowMixedPayment] = useState(false);
  const [showPaymentDetails, setShowPaymentDetails] = useState(false);
  const [showVariantPicker, setShowVariantPicker] = useState(false);
  const [showClearDialog, setShowClearDialog] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<POSProduct | null>(null);
  const [mobileView, setMobileView] = useState<'products' | 'cart'>('products');

  // Hide global bottom nav on mobile cart view so checkout button stays at the bottom
  useEffect(() => {
    const bottomNav = document.getElementById('admin-bottom-nav');
    const mainContent = document.getElementById('admin-main-content');
    
    if (mobileView === 'cart') {
      if (bottomNav) bottomNav.style.display = 'none';
      if (mainContent) mainContent.style.paddingBottom = '0px';
    } else {
      if (bottomNav) bottomNav.style.display = '';
      if (mainContent) mainContent.style.paddingBottom = '';
    }

    return () => {
      if (bottomNav) bottomNav.style.display = '';
      if (mainContent) mainContent.style.paddingBottom = '';
    };
  }, [mobileView]);

  const {
    cart,
    heldOrders,
    addItem,
    updateQuantity,
    removeItem,
    clearCart,
    holdOrder,
    resumeOrder,
    setDiscount,
    setPaymentMethod,
    setAmountReceived,
    setCustomerInfo,
    setNote,
    setPaidAmount,
    setGuarantorInfo,
    setItemPrice,
    resetItemPrice,
    subtotal,
    discountAmount,
    taxAmount,
    grandTotal,
    change,
    totalItems,
  } = usePOSCart();

  const handleProductSelect = useCallback(
    (product: POSProduct, variantId?: string) => {
      // If product has multiple variants and no variant selected, show picker
      if (!variantId && product.items.length > 1) {
        setSelectedProduct(product);
        setShowVariantPicker(true);
        return;
      }
      
      addItem(product, variantId);
      setMobileView('cart'); // auto-switch to cart on mobile
      // Play a subtle sound effect (optional)
      try {
        const audio = new Audio('/sounds/beep.mp3');
        audio.volume = 0.3;
        audio.play().catch(() => {});
      } catch {}
    },
    [addItem]
  );

  const handleCompleteSale = useCallback(async (mixedBreakdown?: { 
    cash: number; 
    card: number; 
    mobile: number;
    mobileTrxId?: string;
    mobileNumber?: string;
    mobileProvider?: string;
    mobileCashOutCharge?: number;
    cardTrxId?: string;
    cardLast4?: string;
  }) => {
    if (cart.items.length === 0) return;
    
    console.log('Payment method:', cart.paymentMethod);
    console.log('Mixed breakdown:', mixedBreakdown);
    
    // Check if it's mixed payment and show modal if not provided
    if (cart.paymentMethod === 'MIXED' && !mixedBreakdown) {
      console.log('Opening mixed payment modal');
      setShowMixedPayment(true);
      return;
    }

    // Check if it's Mobile or Card payment and details not provided (we check if mobileTrxId is missing for Mobile)
    // For Card, we might just want to show confirmation even if no extra data needed yet
    // Note: mixedBreakdown is reused here to pass single payment details for simplicity, or we can check logic
    if ((cart.paymentMethod === 'MOBILE_BANKING' || cart.paymentMethod === 'CARD') && !mixedBreakdown) {
       // Using mixedBreakdown arg to pass details from PaymentDetailsModal as well
       setShowPaymentDetails(true);
       return;
    }
    
    if (cart.paymentMethod === 'CASH' && cart.amountReceived < grandTotal) {
      // Check if it's a due/partial payment with customer info filled
      const hasCustomerInfo = cart.customerName.trim().length > 0 && cart.customerPhone.trim().length > 0;
      const hasGuarantorInfo = cart.guarantorName.trim().length > 0 && cart.guarantorPhone.trim().length > 0;

      if (!hasCustomerInfo || !hasGuarantorInfo) {
        toast.error('Please fill customer and guarantor details for due payment');
        return;
      }

      // Sale will proceed as partial/due payment — amounts computed below
    }

    setIsProcessing(true);
    try {
      // Determine paid/due amounts
      const isCashDue = cart.paymentMethod === 'CASH' && cart.amountReceived > 0 && cart.amountReceived < grandTotal;
      const effectivePaidAmount = isCashDue
        ? cart.amountReceived
        : (cart.paidAmount !== null ? cart.paidAmount : undefined);
      const effectiveDueAmount = isCashDue
        ? grandTotal - cart.amountReceived
        : (cart.paidAmount !== null && cart.paidAmount < grandTotal ? grandTotal - cart.paidAmount : undefined);
      const effectivePosStatus = isCashDue
        ? 'PARTIAL'
        : (cart.paidAmount !== null
            ? (cart.paidAmount <= 0 ? 'DUE' : cart.paidAmount < grandTotal ? 'PARTIAL' : 'PAID')
            : undefined);

      const input: CompleteSaleInput = {
        items: cart.items,
        paymentMethod: cart.paymentMethod,
        subtotal,
        discount: discountAmount,
        tax: taxAmount,
        grandTotal,
        amountReceived: cart.paymentMethod === 'CASH' ? cart.amountReceived : grandTotal,
        change: cart.paymentMethod === 'CASH' && cart.amountReceived >= grandTotal ? change : 0,
        customerName: cart.customerName || undefined,
        customerPhone: cart.customerPhone || undefined,
        note: cart.note || undefined,
        paidAmount: effectivePaidAmount,
        dueAmount: effectiveDueAmount,
        posPaymentStatus: effectivePosStatus,
        guarantorName: cart.guarantorName || undefined,
        guarantorPhone: cart.guarantorPhone || undefined,
        guarantorRelation: cart.guarantorRelation || undefined,
        guarantorAddress: cart.guarantorAddress || undefined,
        ...(mixedBreakdown && {
          cashPayment: mixedBreakdown.cash,
          cardPayment: mixedBreakdown.card,
          mobilePayment: mixedBreakdown.mobile,
          mobileTrxId: mixedBreakdown.mobileTrxId,
          mobileNumber: mixedBreakdown.mobileNumber,
          mobileProvider: mixedBreakdown.mobileProvider,
          mobileCashOutCharge: mixedBreakdown.mobileCashOutCharge,
          cardTrxId: mixedBreakdown.cardTrxId,
          cardLast4: mixedBreakdown.cardLast4,
        }),
      };

      const result = await completeSale(input);

      if (result.success) {
        // Show receipt
        setReceiptData({
          orderNumber: result.orderNumber!,
          items: [...cart.items],
          subtotal,
          discount: discountAmount,
          discountType: cart.discountType,
          discountValue: cart.discount,
          tax: taxAmount,
          grandTotal,
          paymentMethod: cart.paymentMethod,
          amountReceived: cart.paymentMethod === 'CASH' ? cart.amountReceived : grandTotal,
          change: cart.paymentMethod === 'CASH' && cart.amountReceived >= grandTotal ? change : 0,
          customerName: cart.customerName,
          customerPhone: cart.customerPhone,
          paidAmount: effectivePaidAmount,
          dueAmount: effectiveDueAmount ?? 0,
          posPaymentStatus: effectivePosStatus ?? 'PAID',
          guarantorName: cart.guarantorName || undefined,
          guarantorPhone: cart.guarantorPhone || undefined,
          guarantorRelation: cart.guarantorRelation || undefined,
          date: new Date().toLocaleString('en-US', {
            dateStyle: 'medium',
            timeStyle: 'short',
          }),
          ...(mixedBreakdown && {
            cashPayment: mixedBreakdown.cash,
            cardPayment: mixedBreakdown.card,
            mobilePayment: mixedBreakdown.mobile,
            mobileTrxId: mixedBreakdown.mobileTrxId,
            mobileNumber: mixedBreakdown.mobileNumber,
            mobileProvider: mixedBreakdown.mobileProvider,
            mobileCashOutCharge: mixedBreakdown.mobileCashOutCharge,
            cardTrxId: mixedBreakdown.cardTrxId,
            cardLast4: mixedBreakdown.cardLast4,
          }),
        });
        setShowReceipt(true);

        const [summary, dates] = await Promise.all([
          getDailySalesSummary(selectedDate),
          getPOSSalesDates(),
        ]);
        setDailySummary(summary);
        setSalesDates(dates);

        clearCart();
        toast.success(`Sale completed: ${result.orderNumber}`);
        // Refresh server data to get updated stock
        router.refresh();
      } else {
        toast.error(result.error || 'Failed to complete sale');
      }
    } catch (error: any) {
      toast.error(error.message || 'An error occurred');
    } finally {
      setIsProcessing(false);
    }
  }, [cart, subtotal, discountAmount, taxAmount, grandTotal, change, clearCart, router, selectedDate]);

  const handleMixedPaymentConfirm = useCallback((breakdown: { 
    cash: number; 
    card: number; 
    mobile: number;
    mobileTrxId?: string;
    mobileNumber?: string;
    mobileProvider?: string;
    mobileCashOutCharge?: number;
    cardTrxId?: string;
    cardLast4?: string;
  }) => {
    setShowMixedPayment(false);
    handleCompleteSale(breakdown);
  }, [handleCompleteSale]);

  const handlePaymentDetailsConfirm = useCallback((details: {
    mobileTrxId?: string;
    mobileNumber?: string;
    mobileProvider?: string;
    mobileCashOutCharge?: number;
    cardTrxId?: string;
    cardLast4?: string;
  }) => {
    setShowPaymentDetails(false);
    // Pass as "mixedBreakdown" object format to reuse the function, 
    // even though it's single payment. The API handles optional fields.
    // For single payment, we don't need cash/card/mobile amounts split, 
    // but we pass the extra metadata.
    handleCompleteSale({
        cash: 0,
        card: 0,
        mobile: 0, // Amounts ignored for single payment in backend if method is not MIXED
        ...details
    });
  }, [handleCompleteSale]);

  // Keyboard Shortcuts
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement;
      const isInput = target.tagName === 'INPUT' || target.tagName === 'TEXTAREA' || target.isContentEditable;

      // F2 - Focus search
      if (e.key === 'F2') {
        e.preventDefault();
        searchInputRef.current?.focus();
        return;
      }

      // Escape - Clear cart (only when not in input)
      if (e.key === 'Escape' && !isInput) {
        e.preventDefault();
        if (cart.items.length > 0) {
          setShowClearDialog(true);
        }
        return;
      }

      // Ctrl + Enter - Complete sale
      if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
        e.preventDefault();
        handleCompleteSale();
        return;
      }

      // F9 - Hold order
      if (e.key === 'F9') {
        e.preventDefault();
        holdOrder();
        toast.info('Order held');
        return;
      }

      // F11 - Toggle fullscreen
      if (e.key === 'F11' && !isInput) {
        e.preventDefault();
        toggleFullscreen();
        return;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [cart, clearCart, handleCompleteSale, holdOrder, toggleFullscreen]);

  return (
    <div className={cn(
      'flex flex-col bg-white lg:rounded-2xl lg:border border-gray-200 lg:shadow-sm overflow-hidden',
      isFullscreen ? 'fixed inset-0 z-100 rounded-none' : 'h-full w-full'
    )}>
      {/* Top Bar */}
      <div className="flex flex-wrap sm:flex-nowrap items-center justify-between px-3 sm:px-4 pt-1 pb-1 sm:py-2 bg-linear-to-r from-blue-600 to-blue-700 text-white relative gap-y-0">
        
        {/* Mobile Left Placeholder to push Actions to the right */}
        <div className="w-6 h-6 sm:hidden order-1"></div>

        {/* Title: Absolute Center on both mobile and desktop */}
        <div className="absolute left-1/2 -translate-x-1/2 font-extrabold text-base sm:text-lg pointer-events-none top-2 sm:top-1/2 sm:-translate-y-1/2 flex items-center gap-1.5">
          <img src="/images/techhat.png" alt="TechHat Logo" className="h-5 sm:h-6 w-auto object-contain drop-shadow-sm" />
          <span>TechHat POS</span>
        </div>

        {/* Stats: Center on mobile, Left on desktop */}
        <div className="flex justify-center sm:justify-start items-center gap-3 sm:gap-4 text-[11px] sm:text-xs text-blue-50 overflow-x-auto scrollbar-hide w-full sm:w-auto order-3 sm:order-first pt-1 sm:pt-0 border-t border-white/10 sm:border-0 pb-1 sm:pb-0">
          <Popover open={calendarOpen} onOpenChange={setCalendarOpen}>
              <PopoverTrigger asChild>
                 <button className="flex items-center gap-1.5 cursor-pointer hover:text-white transition-colors">
                  <CalendarIcon className="w-3.5 h-3.5" />
                  <span className="font-semibold">{format(new Date(selectedDate), 'MMM d, yyyy')}</span>
                </button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="single"
                  selected={new Date(selectedDate)}
                  onSelect={handleDateChange}
                  captionLayout="dropdown"
                  startMonth={new Date(2020, 0)}
                  endMonth={new Date(new Date().getFullYear() + 5, 11)}
                  disabled={(date) => {
                    const dateStr = format(date, 'yyyy-MM-dd');
                    const todayStr = format(new Date(), 'yyyy-MM-dd');
                    return !salesDates.includes(dateStr) && dateStr !== todayStr;
                  }}
                  modifiers={{
                    hasSales: (date) => salesDates.includes(format(date, 'yyyy-MM-dd')),
                  }}
                  modifiersClassNames={{
                    hasSales: "font-bold text-blue-600 bg-blue-50/50 relative after:content-[''] after:absolute after:bottom-1.5 after:w-1.5 after:h-1.5 after:bg-blue-600 after:rounded-full after:left-1/2 after:-translate-x-1/2",
                  }}
                />
              </PopoverContent>
            </Popover>
            <div className="w-px h-3 bg-white/20"></div>
            <div className="flex items-center gap-1.5">
              <DollarSign className="w-3.5 h-3.5 text-green-300" />
              <span className="font-bold text-white tracking-wide">৳{dailySummary.totalSales.toLocaleString()}</span>
            </div>
            <div className="w-px h-3 bg-white/20"></div>
            <button onClick={() => setShowOrdersModal(true)} className="flex items-center gap-1.5 hover:text-white transition-colors">
              <ShoppingCart className="w-3.5 h-3.5" />
              <span className="font-bold">{dailySummary.totalOrders} orders</span>
            </button>
            <div className="w-px h-3 bg-white/20 hidden sm:block"></div>
            <button onClick={() => setShowOrdersModal(true)} className="hidden sm:flex items-center gap-1.5 hover:text-white transition-colors">
              <Package className="w-3.5 h-3.5" />
              <span className="font-bold">{dailySummary.totalItems} items</span>
            </button>
        </div>

        {/* Actions: Right on both mobile and desktop */}
        <div className="flex items-center gap-1 sm:gap-2 order-2 sm:order-last">
          {/* Desktop Links */}
          <div className="hidden lg:flex items-center gap-2">
            <a href="/admin/pos/reports" className="flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-white text-xs font-semibold transition-colors">
              <BarChart2 className="h-3.5 w-3.5" /> Reports
            </a>
            <a href="/admin/pos/customers" className="flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-white text-xs font-semibold transition-colors">
              <Users className="h-3.5 w-3.5" /> Customers
            </a>
            <a href="/admin/pos/payments" className="flex items-center gap-1.5 px-3 py-1.5 bg-white/10 hover:bg-white/20 rounded-lg text-white text-xs font-semibold transition-colors">
              <CreditCard className="h-3.5 w-3.5" /> Payments
            </a>
          </div>

          {/* Mobile Dropdown Toggle */}
          <div className="relative lg:hidden">
            <button onClick={() => setShowMobileMenu(!showMobileMenu)} className="p-1 hover:bg-white/20 rounded-lg transition-colors text-white">
              <MoreVertical className="h-5 w-5" />
            </button>
            {showMobileMenu && (
              <div className="absolute right-0 top-full mt-2 w-48 bg-white rounded-xl shadow-xl border border-gray-100 p-1.5 z-50 flex flex-col gap-1">
                <a href="/admin/pos/reports" className="flex items-center gap-2 px-3 py-2 text-gray-700 hover:bg-blue-50 hover:text-blue-600 rounded-lg text-sm font-semibold">
                  <BarChart2 className="h-4 w-4" /> Reports
                </a>
                <a href="/admin/pos/customers" className="flex items-center gap-2 px-3 py-2 text-gray-700 hover:bg-blue-50 hover:text-blue-600 rounded-lg text-sm font-semibold">
                  <Users className="h-4 w-4" /> Customers
                </a>
                <a href="/admin/pos/payments" className="flex items-center gap-2 px-3 py-2 text-gray-700 hover:bg-blue-50 hover:text-blue-600 rounded-lg text-sm font-semibold">
                  <CreditCard className="h-4 w-4" /> Payments
                </a>
              </div>
            )}
          </div>

          <button onClick={() => setShowShortcuts(!showShortcuts)} className="p-2 hover:bg-white/10 rounded-lg transition-colors hidden sm:block" title="Keyboard shortcuts">
            <Keyboard className="h-4 w-4" />
          </button>
          <button onClick={toggleFullscreen} className="p-2 hover:bg-white/10 rounded-lg transition-colors hidden sm:block" title="Toggle fullscreen (F11)">
            {isFullscreen ? <Minimize className="h-4 w-4" /> : <Maximize className="h-4 w-4" />}
          </button>
        </div>
      </div>



      {/* Shortcuts Help */}
      {showShortcuts && (
        <div className="bg-gray-900 text-white px-4 py-3 text-xs flex items-center gap-6 flex-wrap animate-in slide-in-from-top-2 fade-in duration-200">
          <span className="font-bold text-gray-400">Shortcuts:</span>
          {[
            { key: 'F2', action: 'Search' },
            { key: 'Ctrl+Enter', action: 'Complete Sale' },
            { key: 'Esc', action: 'Clear Cart' },
            { key: 'F9', action: 'Hold Order' },
            { key: 'F11', action: 'Fullscreen' },
          ].map((s) => (
            <span key={s.key} className="flex items-center gap-1.5">
              <kbd className="bg-gray-700 px-2 py-0.5 rounded font-mono text-[10px]">{s.key}</kbd>
              <span className="text-gray-300">{s.action}</span>
            </span>
          ))}
          <button onClick={() => setShowShortcuts(false)} className="ml-auto text-gray-400 hover:text-white">
            ✕
          </button>
        </div>
      )}

      {/* Mobile Tab Bar */}
      <div className="lg:hidden flex border-b border-gray-200 bg-gray-50 shrink-0">
        <button
          onClick={() => setMobileView('products')}
          className={cn(
            'flex-1 py-2.5 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors',
            mobileView === 'products'
              ? 'text-blue-600 border-b-2 border-blue-600 bg-white'
              : 'text-gray-500'
          )}
        >
          <Grid3X3 className="w-4 h-4" />
          Products
        </button>
        <button
          onClick={() => setMobileView('cart')}
          className={cn(
            'flex-1 py-2.5 text-xs font-bold flex items-center justify-center gap-1.5 transition-colors',
            mobileView === 'cart'
              ? 'text-blue-600 border-b-2 border-blue-600 bg-white'
              : 'text-gray-500'
          )}
        >
          <ShoppingCart className="w-4 h-4" />
          <span>Cart</span>
          {totalItems > 0 && (
            <div className="flex items-center gap-1.5 ml-1 px-2 py-0.5 bg-blue-100 text-blue-700 rounded-full">
              <span className="text-[10px] font-black">{totalItems}</span>
              <span className="text-[10px] font-bold border-l border-blue-200 pl-1.5">৳{grandTotal.toLocaleString()}</span>
            </div>
          )}
        </button>
      </div>

      {/* Main Content - Two Column */}
      <div className="flex-1 flex overflow-hidden">
        {/* Left: Product Selection */}
        <div className={cn(
          'flex-1 flex flex-col border-r border-gray-200 min-w-0',
          mobileView === 'products' ? 'flex' : 'hidden lg:flex'
        )}>
          <POSProductGrid
            categories={categories}
            onProductSelect={handleProductSelect}
            searchInputRef={searchInputRef}
            initialProducts={initialProducts}
          />
        </div>

        {/* Right: Cart & Checkout */}
        <div className={cn(
          'shrink-0 flex flex-col',
          mobileView === 'cart' ? 'flex w-full lg:flex lg:w-[26.25rem]' : 'hidden lg:flex lg:w-[26.25rem]'
        )}>
          <POSCartPanel
            cart={cart}
            subtotal={subtotal}
            discountAmount={discountAmount}
            taxAmount={taxAmount}
            grandTotal={grandTotal}
            change={change}
            totalItems={totalItems}
            heldOrders={heldOrders}
            onUpdateQuantity={updateQuantity}
            onRemoveItem={removeItem}
            onClearCart={clearCart}
            onRequestClear={() => setShowClearDialog(true)}
            onHoldOrder={holdOrder}
            onResumeOrder={resumeOrder}
            onSetDiscount={setDiscount}
            onSetPaymentMethod={setPaymentMethod}
            onSetAmountReceived={setAmountReceived}
            onSetCustomerInfo={setCustomerInfo}
            onSetNote={setNote}
            onSetPaidAmount={setPaidAmount}
            onSetGuarantorInfo={setGuarantorInfo}
            onSetItemPrice={setItemPrice}
            onResetItemPrice={resetItemPrice}
            onCompleteSale={handleCompleteSale}
            isProcessing={isProcessing}
            customers={posCustomers}
            onCustomerCreated={() => getPOSCustomerList().then((data) => setPosCustomers(data)).catch(() => {})}
          />
        </div>
      </div>

      {/* Receipt Modal */}
      <POSReceipt
        isOpen={showReceipt}
        onClose={() => setShowReceipt(false)}
        receipt={receiptData}
        invoiceSettings={invoiceSettings}
      />

      {/* Clear Cart Dialog */}
      <ClearCartDialog
        open={showClearDialog}
        onOpenChange={setShowClearDialog}
        onConfirm={() => {
          clearCart();
          toast.info('Cart cleared');
        }}
      />

      {showOrdersModal && (
        <DailyOrdersModal
          isOpen={showOrdersModal}
          onClose={() => setShowOrdersModal(false)}
          targetDate={selectedDate}
        />
      )}

      {/* Mixed Payment Modal */}
      <MixedPaymentModal
        isOpen={showMixedPayment}
        onClose={() => setShowMixedPayment(false)}
        grandTotal={grandTotal}
        onConfirm={handleMixedPaymentConfirm}
      />

      {/* Single Payment Details Modal */}
      <PaymentDetailsModal
        isOpen={showPaymentDetails}
        onClose={() => setShowPaymentDetails(false)}
        grandTotal={grandTotal}
        paymentMethod={cart.paymentMethod === 'MOBILE_BANKING' ? 'MOBILE_BANKING' : 'CARD'}
        onConfirm={handlePaymentDetailsConfirm}
      />

      {/* Variant Picker Modal */}
      <VariantPickerModal
        isOpen={showVariantPicker}
        onClose={() => {
          setShowVariantPicker(false);
          setSelectedProduct(null);
        }}
        product={selectedProduct}
        onSelectVariant={handleProductSelect}
      />
    </div>
  );
}
